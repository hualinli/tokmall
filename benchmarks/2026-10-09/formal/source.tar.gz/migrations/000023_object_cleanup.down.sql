DROP TABLE object_delete_jobs;
