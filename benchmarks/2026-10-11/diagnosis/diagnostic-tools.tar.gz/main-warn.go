package main

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
 _ "net/http/pprof"
 "runtime"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/app/server"
	"github.com/cloudwego/hertz/pkg/common/hlog"
	"github.com/golang-migrate/migrate/v4"
	"github.com/google/uuid"
	hertzslog "github.com/hertz-contrib/logger/slog"
	hertzmonitor "github.com/hertz-contrib/monitor-prometheus"
	"github.com/hertz-contrib/requestid"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/redis/go-redis/v9"
	"gopkg.in/natefinch/lumberjack.v2"
	"gorm.io/gorm"

	"github.com/lihualin/tokmall/internal/api"
	"github.com/lihualin/tokmall/internal/attribution"
	"github.com/lihualin/tokmall/internal/breaker"
	"github.com/lihualin/tokmall/internal/cache"
	"github.com/lihualin/tokmall/internal/cache/l1"
	"github.com/lihualin/tokmall/internal/config"
	"github.com/lihualin/tokmall/internal/coupon"
	"github.com/lihualin/tokmall/internal/database"
	"github.com/lihualin/tokmall/internal/existence"
	"github.com/lihualin/tokmall/internal/feed"
	"github.com/lihualin/tokmall/internal/health"
	"github.com/lihualin/tokmall/internal/interaction"
	"github.com/lihualin/tokmall/internal/inventory"
	"github.com/lihualin/tokmall/internal/middleware"
	"github.com/lihualin/tokmall/internal/observability"
	"github.com/lihualin/tokmall/internal/order"
	"github.com/lihualin/tokmall/internal/outbox"
	"github.com/lihualin/tokmall/internal/product"
	"github.com/lihualin/tokmall/internal/promotion"
	"github.com/lihualin/tokmall/internal/reconcile"
	"github.com/lihualin/tokmall/internal/storage"
	"github.com/lihualin/tokmall/internal/token"
	"github.com/lihualin/tokmall/internal/user"
	"github.com/lihualin/tokmall/internal/video"
)

func main() {
	if err := run(); err != nil {
		slog.Error("server exited", "err", err)
		os.Exit(1)
	}
}

func run() error {
 runtime.SetBlockProfileRate(1000000)
 runtime.SetMutexProfileFraction(10)
 go func(){ _ = http.ListenAndServe("127.0.0.1:19092", nil) }()
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	ranker, err := newRanker(cfg.FeedRankStrategy)
	if err != nil {
		return fmt.Errorf("configure feed ranker: %w", err)
	}
	logger := &lumberjack.Logger{
		Filename:   "logs/app.log",
		MaxSize:    20,
		MaxBackups: 5,
		MaxAge:     10,
		Compress:   true,
	}
	textHandler := slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelWarn})
	jsonHandler := slog.NewJSONHandler(logger, &slog.HandlerOptions{Level: slog.LevelWarn})
	multiHandler := slog.NewMultiHandler(textHandler, jsonHandler)
	// ContextHandler 是"日志能串起来"的关键：它从 context 取
	// request_id/trace_id/span_id/route/user_id 自动附加，并对敏感字段脱敏。
	// 业务代码只要用 slog.*Context(ctx, ...) 就自动带上，不依赖自觉。
	slog.SetDefault(slog.New(observability.NewContextHandler(multiHandler)))
	hlog.SetLogger(hertzslog.NewLogger(
		hertzslog.WithOutput(logger),
		hertzslog.WithHandlerOptions(&slog.HandlerOptions{Level: slog.LevelDebug}),
	))

	metricsRegistry := prometheus.NewRegistry()
	db, err := database.Connect(cfg.DBConfig)
	if err != nil {
		return fmt.Errorf("connect databse: %w", err)
	}
	sqlDB, err := db.DB()
	if err != nil {
		return fmt.Errorf("get sql db: %w", err)
	}
	metricsRegistry.MustRegister(observability.NewDBPoolCollector(sqlDB, "tokmall"))
	err = database.Migrate(db)
	if err != nil && !errors.Is(err, migrate.ErrNoChange) {
		return fmt.Errorf("database migrate: %w", err)
	}
	// 热榜：分钟桶 + 冻结窗口。读路径只读（后台 worker 每分钟物化一次），
	// 窗口缺失时才由 singleflight 合并回源（见 internal/feed/hot_cache.go）。
	// 计分器在这里就绪：interaction（点赞）与 video（播放）都要用它。
	var hotFeed *feed.RedisHotFeed
	var hotScoreRecorder feed.HotScoreRecorder
	var hotMetrics *observability.HotFeedMetrics
	redisClient, err := cache.NewClient(cfg.RedisConfig,
		// 慢命令日志：缓存命中后瓶颈就在 Redis 读上（见 performance-baseline），
		// 没有这层日志就只能看到"命中率"，看不到"哪条命令慢"。
		cache.WithSlowCommandLogging(cache.SlowCommandThreshold, observability.NewRedisMetrics(metricsRegistry)))
	if err != nil {
		return fmt.Errorf("connect redis: %w", err)
	}
	defer func() { _ = redisClient.Close() }()
	if cfg.HotFeedEnabled {
		hotMetrics = observability.NewHotFeedMetrics(metricsRegistry)
		hotFeed = feed.NewRedisHotFeed(redisClient, hotMetrics)
		hotScoreRecorder = hotFeed
	}
	addr := fmt.Sprintf(":%s", cfg.ServerPort)
	h := server.New(
		server.WithHostPorts(addr),
		server.WithMaxRequestBodySize(64<<10), // API 只收 JSON；媒体本体直传对象存储。
		server.WithTracer(hertzmonitor.NewServerTracer(
			cfg.MetricsAddr, "/metrics",
			hertzmonitor.WithRegistry(metricsRegistry),
			hertzmonitor.WithEnableGoCollector(true),
		)),
	)
	// Hertz 默认把 0.0.0.0/0 与 ::/0 都当作可信代理，于是客户端自带的
	// X-Forwarded-For 会被 ClientIP() 原样采信——按 IP 的限流（登录、读接口）
	// 就能被逐请求伪造绕过。这里只信任配置显式声明的入口网段；
	// 未配置时不解析任何转发头，直接使用 TCP 对端地址。
	h.SetClientIPFunc(app.ClientIPWithOption(app.ClientIPOptions{
		RemoteIPHeaders: []string{"X-Forwarded-For", "X-Real-IP"},
		TrustedCIDRs:    cfg.TrustedProxies,
	}))
	slog.Info("server starting", "port", cfg.ServerPort)
	httpMetrics := observability.NewHTTPMetrics(metricsRegistry)
	h.Use(
		middleware.Recovery(),
		requestid.New(
			requestid.WithGenerator(func(ctx context.Context, c *app.RequestContext) string {
				return uuid.Must(uuid.NewV7()).String()
			}),
		),
		// 顺序：requestid → trace（需要 requestid 写入 context）→ 指标/访问日志
		middleware.Trace(),
		middleware.HTTPMetrics(httpMetrics),
		middleware.AccessLog(),
	)
	rawStorage, err := storage.New(cfg.S3Config)
	if err != nil {
		return fmt.Errorf("init storage: %w", err)
	}
	// 对象存储的熔断装饰器：S3 对象存储不可用时快速失败，业务侧降级
	// （卡片无封面/详情无播放地址），而不是让每个请求都等到底层超时。
	var storageClient breaker.StorageClient = rawStorage
	if cfg.BreakerEnabled {
		storageClient = breaker.NewStorage(rawStorage, breaker.New(breaker.Config{
			Name:             "s3",
			FailureThreshold: cfg.BreakerFailureThreshold,
			OpenDuration:     cfg.BreakerOpenDuration,
			MaxOpenDuration:  cfg.BreakerMaxOpen,
			HalfOpenProbes:   1,
			// "对象不存在"是健康依赖的正常答复，不能计成故障——
			// 否则一次正常的 404 就能把熔断器打开。
			IsFailure: func(err error) bool {
				return !errors.Is(err, storage.ErrObjectNotFound) && !errors.Is(err, storage.ErrInvalidObjectSize)
			},
		}, breaker.WithStats(observability.NewBreakerMetrics(metricsRegistry))))
	}
	// 注意：必须用 nil 接口变量。直接声明 *feed.RedisFeedCache 再赋给接口，
	// 关闭时会得到"typed nil"——接口判 nil 为真但方法调用即 panic。
	feedCacheStats := observability.NewFeedCacheStats(metricsRegistry)
	l1Metrics := observability.NewL1CacheMetrics(metricsRegistry)
	var feedCache feed.FirstPageCache
	var feedInvalidator video.FeedCacheInvalidator
	if cfg.FeedCacheEnabled {
		redisFeedCache := feed.NewRedisFeedCache(redisClient, cfg.FeedCacheTTL)
		if cfg.FeedL1Enabled {
			// 两级缓存：L1 进程内（内存查表）+ L2 Redis。
			// 版本号是跨实例失效的载体：写路径递增，读路径校验（见 feed.VersionStamp）。
			versionStamp := feed.NewVersionStamp(redisClient, cfg.FeedVersionInterval)
			tiered := feed.NewTieredFeedCache(feed.TieredCacheOptions{
				L2:      redisFeedCache,
				L1:      l1.New(16, cfg.FeedL1Capacity, l1.WithTTL(cfg.FeedL1TTL), l1.WithMetrics(l1Metrics)),
				Version: versionStamp,
				Stats:   feedCacheStats,
			})
			feedCache = tiered
			feedInvalidator = tiered
		} else {
			feedCache = redisFeedCache
			feedInvalidator = redisFeedCache
		}
	}
	followingCache, followingFeedInvalidator := assembleFollowingFeedCache(cfg.RedisConfig, redisClient)
	// 限流器（M7）：Redis 固定窗口计数；关闭（压测/调试）时 nil，registerRoutes 不挂载。
	var rateLimiter middleware.Limiter
	if cfg.RateLimitEnabled {
		rateLimiter = middleware.NewRedisLimiter(redisClient)
	}
	tokenManager := token.NewManager([]byte(cfg.JWTSecret))
	videoRepository := video.NewRepository(db)
	videoService := video.NewService(
		videoRepository,
		storageClient,
		cfg.UploadURLExpiry,
		cfg.CursorSecret,
		feedInvalidator,
	)
	videoService.SetMediaProbeEnabled(cfg.MediaProbeEnabled)
	videoService.SetProductCardReader(video.NewProductCardReader(db))
	userHandler := user.NewHandler(user.NewService(
		user.NewRepository(db),
		tokenManager,
		user.NewRedisRefreshTokenBlacklist(redisClient),
		storageClient,
		videoService,
	))
	feedService := feed.NewService(
		feed.NewRepository(db),
		feed.NewCodec(cfg.CursorSecret),
		storageClient,
		feedCache,
		followingCache,
		feedCacheStats,
		ranker,
	)
	feedService.SetProductCardReader(feed.NewProductCardReader(db))
	if hotScoreRecorder != nil {
		videoService.SetHotScoreRecorder(hotScoreRecorder)
	}
	if hotFeed != nil {
		feedService.SetHotFeed(hotFeed, hotMetrics)
	}
	feedHandler := feed.NewHandler(feedService)
	videoHandler := video.NewHandler(videoService)
	interactionService := interaction.NewService(
		interaction.NewRepository(db),
		storageClient,
		cfg.CursorSecret,
		followingFeedInvalidator,
	)
	if hotScoreRecorder != nil {
		// 点赞/取消点赞计分（只有"状态真的变化"时才计，见 interaction.Service.Like）。
		interactionService.SetHotScoreRecorder(hotScoreRecorder)
	}
	interactionHandler := interaction.NewHandler(interactionService)
	productRepository := product.NewRepository(db)
	productService := product.NewService(
		productRepository,
		storageClient,
		videoService, // ImageTicketValidator：封面防伪造复用视频模块的凭证核销
	)
	productHandler := product.NewHandler(productService)
	// 缓存穿透防护：布隆过滤器（进程内）+ 负缓存（Redis）。
	// 装配在这里而不是模块内部：video/product 只依赖"能否问一句是否存在"的接口。
	var existenceGuard *existence.Guard
	var existenceMetrics *observability.ExistenceMetrics
	if cfg.ExistenceEnabled {
		existenceMetrics = observability.NewExistenceMetrics(metricsRegistry)
		existenceGuard = existence.NewGuard(
			map[string]uint64{"video": cfg.ExistenceExpected, "product": cfg.ExistenceExpected},
			existence.NewRedisMissingMarker(redisClient),
			cfg.ExistenceFPRate,
			existence.WithTTL(cfg.ExistenceNegativeTTL),
			existence.WithJitter(cfg.ExistenceNegativeJitter),
			existence.WithStats(existenceMetrics),
		)
		videoService.SetExistenceGuard(existenceGuard)
		productService.SetExistenceGuard(existenceGuard)
	}

	inventoryHandler := inventory.NewHandler(inventory.NewService(
		inventory.NewRepository(db),
	))
	orderRepository := order.NewRepository(db)
	orderService := order.NewService(orderRepository)
	// 同一 GormRepository 同时实现订单命令与退款命令；注入分开是为了让
	// service 只依赖它真正使用的消费侧接口。
	orderService.SetRefundRepository(orderRepository)
	orderHandler := order.NewHandler(orderService)
	promotionHandler := promotion.NewHandler(promotion.NewService(promotion.NewRepository(db)))
	couponHandler := coupon.NewHandler(coupon.NewService(coupon.NewRepository(db)))
	attributionHandler := attribution.NewHandler(attribution.NewService(attribution.NewRepository(db)))
	// 媒体校验 worker：只在开启时构造（未开启时新视频显式 SKIPPED）。
	var mediaProbeWorker *video.ProbeWorker
	if cfg.MediaProbeEnabled {
		mediaProbeWorker = video.NewProbeWorker(videoRepository, storageClient,
			video.WithProbePolicy(video.MediaProbePolicy(cfg)),
			video.WithProbeStats(observability.NewMediaProbeMetrics(metricsRegistry)),
			video.WithProbeInterval(cfg.MediaProbeInterval),
			video.WithProbeBatch(cfg.MediaProbeBatch),
		)
	}
	workers := startWorkers(ctx, cfg, db, redisClient, orderRepository, metricsRegistry, existenceGuard, existenceMetrics, videoRepository, productRepository, hotFeed, mediaProbeWorker, storageClient)
	registerRoutes(h, routes{
		db:          db,
		token:       tokenManager,
		user:        userHandler,
		video:       videoHandler,
		feed:        feedHandler,
		interaction: interactionHandler,
		product:     productHandler,
		inventory:   inventoryHandler,
		order:       orderHandler,
		promotion:   promotionHandler,
		attribution: attributionHandler,
		coupon:      couponHandler,
		rateLimiter: rateLimiter,
		rateRules: rateRules{
			authAccount: middleware.RateLimitRule{Scope: "auth-account", Limit: cfg.AuthAccountLimit, Window: time.Minute},
			authIP:      middleware.RateLimitRule{Scope: "auth-ip", Limit: cfg.AuthIPLimit, Window: time.Minute},
			read:        middleware.RateLimitRule{Scope: "read", Limit: cfg.ReadRateLimit, Window: time.Minute},
			write:       middleware.RateLimitRule{Scope: "write", Limit: cfg.WriteRateLimit, Window: 10 * time.Second, ByUser: true},
		},
	})
	errCh := make(chan error, 1)
	go func() {
		errCh <- h.Run()
	}()
	// 指标端口由 hertz 的 tracer 内部起监听，绑定失败不会让主进程退出。
	// 那样会得到一个"服务在跑、观测性却静默消失"的状态——比启动失败更危险，
	// 因此这里主动探一次并大声报错（快速重启时端口可能还在 TIME_WAIT）。
	go verifyMetricsEndpoint(ctx, cfg.MetricsAddr)
	select {
	case err := <-errCh:
		_ = workers.stopAll(30 * time.Second)
		return err
	case <-ctx.Done():
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		shutdownErr := h.Shutdown(shutdownCtx)
		workerStopErr := workers.stopAll(30 * time.Second)
		if shutdownErr != nil {
			return fmt.Errorf("shutdown: %w", shutdownErr)
		}
		if workerStopErr != nil {
			return workerStopErr
		}
		if sqlDB, err := db.DB(); err == nil {
			_ = sqlDB.Close()
		}
		slog.Info("server stopped gracefully")
		return nil
	}
}

// backgroundWorkers 汇总所有后台任务（超时关单、Outbox 中继、事件消费者），
// 让"启动/优雅停机"集中在一处，而不是散落在 run() 的各个分支里。
type backgroundWorkers struct {
	stops []func(timeout time.Duration) error
}

func (w *backgroundWorkers) add(cancel context.CancelFunc, done <-chan struct{}, name string) {
	w.stops = append(w.stops, func(timeout time.Duration) error {
		return stopWorker(name, cancel, done, timeout)
	})
}

// stopAll 逆序停机：先停消费者（停止写入读模型），再停中继（停止投递），
// 最后停关单 Worker。任一超时都要报出来，而不是静默返回。
func (w *backgroundWorkers) stopAll(timeout time.Duration) error {
	var firstErr error
	for i := len(w.stops) - 1; i >= 0; i-- {
		if err := w.stops[i](timeout); err != nil && firstErr == nil {
			firstErr = err
		}
	}
	return firstErr
}

func stopWorker(name string, cancel context.CancelFunc, done <-chan struct{}, timeout time.Duration) error {
	if cancel == nil {
		return nil
	}
	cancel()
	timer := time.NewTimer(timeout)
	defer timer.Stop()
	select {
	case <-done:
		return nil
	case <-timer.C:
		return fmt.Errorf("%s shutdown timed out", name)
	}
}

// startWorkers 装配并启动后台任务。顺序刻意是"中继先于消费者"：
// 消费组可以先建立，事件随后到达，不会出现"事件已在流里但没有消费者"。
func startWorkers(ctx context.Context, cfg *config.Config, db *gorm.DB, redisClient *redis.Client,
	orderRepo *order.GormRepository, registry *prometheus.Registry,
	guard *existence.Guard, existenceMetrics *observability.ExistenceMetrics,
	videoRepo *video.GormRepository, productRepo *product.GormRepository,
	hotFeed *feed.RedisHotFeed, mediaProbe *video.ProbeWorker, cleanupStorage video.ObjectDeleter) *backgroundWorkers {
	workers := &backgroundWorkers{}
	cleanupCtx, cleanupCancel := context.WithCancel(ctx)
	cleanupDone := make(chan struct{})
	workers.add(cleanupCancel, cleanupDone, "object cleanup worker")
	go func() { defer close(cleanupDone); video.NewCleanupWorker(db, cleanupStorage).Run(cleanupCtx) }()

	if mediaProbe != nil {
		// 媒体校验 worker：异步 ffprobe 校验 + faststart remux。
		// 放在异步侧的原因见 internal/video/probe_worker.go 顶部注释。
		workerCtx, cancel := context.WithCancel(ctx)
		done := make(chan struct{})
		workers.add(cancel, done, "media probe worker")
		go func() {
			defer close(done)
			mediaProbe.Run(workerCtx)
		}()
	}
	if hotFeed != nil {
		// 热榜窗口后台物化：每分钟把 60 个分钟桶合并成冻结窗口。
		// 读路径因此只读不算（窗口缺失时才 singleflight 回源），
		// 避免"窗口刚过期的那一瞬间每个请求都做一次 60-key 合并"。
		worker := feed.NewHotWindowWorker(hotFeed, time.Minute)
		workerCtx, cancel := context.WithCancel(ctx)
		done := make(chan struct{})
		workers.add(cancel, done, "hot window worker")
		go func() {
			defer close(done)
			worker.Run(workerCtx)
		}()
	}
	if guard != nil {
		worker := existence.NewRebuildWorker(guard, cfg.ExistenceRebuildInterval,
			map[string]existence.LoaderFunc{
				"video": func(ctx context.Context, add func(int64) error) error { return videoRepo.EachVideoID(ctx, 1000, add) },
				"product": func(ctx context.Context, add func(int64) error) error {
					return productRepo.EachProductID(ctx, 1000, add)
				},
			},
			observability.NewExistenceMetricsObserver(existenceMetrics))
		workerCtx, cancel := context.WithCancel(ctx)
		done := make(chan struct{})
		workers.add(cancel, done, "existence rebuild worker")
		go func() {
			defer close(done)
			worker.Run(workerCtx)
		}()
	}
	if cfg.OrderExpiryWorkerEnabled {
		expiryWorker := order.NewExpiryWorker(orderRepo, cfg.OrderExpiryWorkerInterval, cfg.OrderExpiryWorkerBatchSize)
		workerCtx, cancel := context.WithCancel(ctx)
		done := make(chan struct{})
		workers.add(cancel, done, "order expiry worker")
		go func() {
			defer close(done)
			expiryWorker.Run(workerCtx)
		}()
	}
	if redisClient == nil {
		return workers
	}
	outboxRepo := outbox.NewRepository(db)
	if cfg.OutboxRelayEnabled {
		publisher := outbox.Publisher(outbox.NewRedisStreamPublisher(redisClient, cfg.OutboxStream, cfg.OutboxStreamMaxLen))
		relay := outbox.NewRelay(outboxRepo, publisher, cfg.OutboxRelayInterval, cfg.OutboxRelayBatchSize,
			cfg.OutboxRelayLease, int32(cfg.OutboxMaxAttempts),
			outbox.WithRelayStats(observability.NewOutboxRelayMetrics(registry)))
		relayCtx, cancel := context.WithCancel(ctx)
		done := make(chan struct{})
		workers.add(cancel, done, "outbox relay")
		go func() {
			defer close(done)
			relay.Run(relayCtx)
		}()
	}
	if cfg.ReconcileEnabled {
		runner := reconcile.NewRunner(reconcile.NewRepository(db),
			reconcile.WithGrace(cfg.ReconcileGrace),
			// 回执按 (consumer, event_id) 存，不告诉对账用哪个组，它就无法判断
			// “有没有回执”——必须与消费者实际使用的组名一致。
			reconcile.WithConsumer(cfg.OutboxConsumerGroup),
			reconcile.WithStats(observability.NewReconcileMetrics(registry)))
		worker := reconcile.NewWorker(runner, cfg.ReconcileInterval, true)
		workerCtx, cancel := context.WithCancel(ctx)
		done := make(chan struct{})
		workers.add(cancel, done, "reconcile worker")
		go func() {
			defer close(done)
			worker.Run(workerCtx)
		}()
	}
	if cfg.OutboxConsumerEnabled {
		handlers := []outbox.Handler{
			attribution.NewProjector(db),
			// 订单超时延迟事件：加速器（轮询 Worker 仍是安全网）。
			order.NewTimeoutHandler(db, order.WithTimeoutStats(observability.NewOrderTimeoutMetrics(registry))),
		}
		consumer := outbox.NewConsumer(db, redisClient, cfg.OutboxStream, cfg.OutboxConsumerGroup,
			cfg.OutboxDLQStream, consumerName(), handlers,
			outbox.WithConsumerStats(observability.NewOutboxConsumerMetrics(registry)))
		consumerCtx, cancel := context.WithCancel(ctx)
		done := make(chan struct{})
		workers.add(cancel, done, "outbox consumer")
		go func() {
			defer close(done)
			consumer.Run(consumerCtx)
		}()
	}
	return workers
}

// verifyMetricsEndpoint 在启动后确认 /metrics 真的可访问。
// 观测性缺失必须是显式故障，而不是"看起来一切正常"。
func verifyMetricsEndpoint(ctx context.Context, addr string) {
	client := &http.Client{Timeout: 2 * time.Second}
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		select {
		case <-ctx.Done():
			return
		case <-time.After(500 * time.Millisecond):
		}
		response, err := client.Get("http://" + addr + "/metrics")
		if err != nil {
			continue
		}
		_ = response.Body.Close()
		if response.StatusCode == http.StatusOK {
			slog.Info("metrics endpoint ready", "addr", addr)
			return
		}
	}
	slog.Error("metrics endpoint is not reachable; observability is degraded", "addr", addr)
}

// consumerName 让同一个消费组里的多个实例可区分（Redis 用它记录 PEL 归属）。
func consumerName() string {
	host, err := os.Hostname()
	if err != nil {
		host = "unknown"
	}
	return fmt.Sprintf("%s-%d", host, os.Getpid())
}

// assembleFollowingFeedCache 在 main 统一装配 feed 的缓存实现，并把同一个实例
// 以 interaction 消费侧接口注入关注服务。缓存关闭时返回真正的 nil 接口，避免
// typed nil 在关注写路径上触发方法调用；关闭缓存只损失性能，不改变关注正确性。
func assembleFollowingFeedCache(cfg config.RedisConfig, redisClient *redis.Client) (feed.FollowingFeedCache, interaction.FollowingFeedInvalidator) {
	if !cfg.FollowingCacheEnabled || redisClient == nil {
		return nil, nil
	}
	c := feed.NewRedisFollowingFeedCache(redisClient, cfg.FeedCacheTTL)
	return c, c
}

// newRanker 根据生产配置装配排序器。
// 当前只有 time 能与关注 Feed 的 (published_at,id) 游标组成正确的在线分页。
// HotRanker 保留在 feed 包中做排序实验，但在分页语义闭合前拒绝启动。
func newRanker(strategy string) (feed.Ranker, error) {
	switch strategy {
	case "time":
		return feed.TimeRanker{}, nil
	case "hot":
		return nil, fmt.Errorf("hot rank strategy is experimental and does not support cursor pagination")
	default:
		return nil, fmt.Errorf("unknown feed rank strategy %q", strategy)
	}
}

// routes 集中持有各模块 handler，registerRoutes 是唯一的路由注册点：
// 同步测试（main_test.go）用 nil handler 复用同一注册逻辑，
// 保证 openapi.yaml 与代码路由不脱节。rateLimiter 为 nil 时（限流关闭）
// 不挂任何限流中间件，route-sync 测试不受影响。
type routes struct {
	db          *gorm.DB
	token       *token.Manager
	user        *user.Handler
	video       *video.Handler
	feed        *feed.Handler
	interaction *interaction.Handler
	product     *product.Handler
	inventory   *inventory.Handler
	order       *order.Handler
	promotion   *promotion.Handler
	attribution *attribution.Handler
	coupon      *coupon.Handler
	rateLimiter middleware.Limiter
	rateRules   rateRules
}

// rateRules 限流规则（挂载点见 registerRoutes）：
//   - authAccount：仅登录与注册，按账号标识符 10/min（防暴力破解——爆破的维度是账号不是 IP，NAT 下多人
//     共享 IP 按 IP 限会误伤真实用户）；
//   - authIP：按 IP 100/min（放宽版，防单一来源洪峰）；
//   - read：按 IP 6000/min（只挡爬虫/洪峰，阈值远高于真实用户行为）；
//   - write：按用户 100/10s（登录写操作，天然低频）。
type rateRules struct {
	authAccount middleware.RateLimitRule
	authIP      middleware.RateLimitRule
	read        middleware.RateLimitRule
	write       middleware.RateLimitRule
}

// authIPMW 是所有 /auth 路由共用的前置：请求体上限，再按 IP 配额。
// 它先于账号配额执行，因此 IP 超限的请求不会制造账号 key。请求体限制始终启用；
// 关闭限流只移除 Redis 计数。
func authIPMW(r routes) []app.HandlerFunc {
	mw := []app.HandlerFunc{middleware.AuthBodyLimit()}
	if r.rateLimiter == nil {
		return mw
	}
	return append(mw, middleware.RateLimit(r.rateLimiter, r.rateRules.authIP))
}

// authCredentialMW 只挂在携带账号标识符的登录与注册上（见 user.Handler.RegisterRoutes）。
// refresh 与 logout 没有标识符，若也套用会回退为按 IP 计 10/min，共享出口的用户会互相挤占。
func authCredentialMW(r routes) []app.HandlerFunc {
	if r.rateLimiter == nil {
		return nil
	}
	return []app.HandlerFunc{
		middleware.RateLimit(r.rateLimiter, r.rateRules.authAccount, middleware.AccountKeyExtractor),
	}
}

func registerRoutes(h *server.Hertz, r routes) {
	health.NewHandler(r.db).Register(h)
	g := h.Group("/api/v1")
	g.GET("/docs/openapi.yaml", func(ctx context.Context, c *app.RequestContext) {
		c.Response.Header.SetContentType("application/yaml")
		c.Response.SetBody(api.Spec)
	})
	// 读接口限流（IP 级）：挂在 g 上，auth 子组与 optional/protected 组自动继承；
	// /auth 路由先过 IP 配额；仅登录与注册再叠加按标识符配额（见 authCredentialMW）。
	if r.rateLimiter != nil {
		g.Use(middleware.RateLimit(r.rateLimiter, r.rateRules.read))
	}
	r.user.RegisterRoutes(g, authIPMW(r), authCredentialMW(r))
	optional := g.Group("/", middleware.AuthOptional(r.token))
	r.user.RegisterOptionalRoutes(optional)
	r.video.RegisterOptionalRoutes(optional)
	r.interaction.RegisterOptionalRoutes(optional)
	r.product.RegisterOptionalRoutes(optional)
	r.promotion.RegisterOptionalRoutes(optional)
	r.coupon.RegisterOptionalRoutes(optional)
	protected := g.Group("/", middleware.AuthMiddleware(r.token))
	if r.rateLimiter != nil {
		// 写接口：用户级限流（ByUser，登录后按 user_id）
		protected.Use(middleware.RateLimit(r.rateLimiter, r.rateRules.write))
	}
	r.user.RegisterProtectedRoutes(protected)
	r.video.RegisterProtectedRoutes(protected)
	r.feed.RegisterRoutes(g)
	r.feed.RegisterProtectedRoutes(protected)
	r.interaction.RegisterProtectedRoutes(protected)
	r.product.RegisterProtectedRoutes(protected)
	r.inventory.RegisterProtectedRoutes(protected)
	r.order.RegisterProtectedRoutes(protected)
	r.promotion.RegisterProtectedRoutes(protected)
	r.attribution.RegisterProtectedRoutes(protected)
	r.coupon.RegisterProtectedRoutes(protected)
}
