package main

import (
 "context"
 "encoding/json"
 "os"
 "time"
 "database/sql"
 _ "github.com/jackc/pgx/v5/stdlib"
 "github.com/redis/go-redis/v9"
)

func main() {
 ctx:=context.Background()
 db,err:=sql.Open("pgx",os.Getenv("OBSERVER_DSN"));if err!=nil{panic(err)};defer db.Close()
 db.SetMaxOpenConns(1)
 client:=redis.NewClient(&redis.Options{Addr:"127.0.0.1:6379",DB:14});defer client.Close()
 stream:="tokmall:diagnostic:events"
 if os.Getenv("SNAPSHOT")!="" {
  messages,err:=client.XRange(ctx,stream,"-","+").Result();if err!=nil{panic(err)}
  dlq,_:=client.XRange(ctx,stream+":dlq","-","+").Result()
  groups,_:=client.XInfoGroups(ctx,stream).Result()
  json.NewEncoder(os.Stdout).Encode(map[string]any{"messages":messages,"dlq":dlq,"groups":groups});return
 }
 enc:=json.NewEncoder(os.Stdout)
 for n:=0;;n++ {
  var activity string
  err=db.QueryRow(`SELECT coalesce(json_agg(json_build_object('pid',pid,'state',state,'wait_type',wait_event_type,'wait_event',wait_event,'blocking',pg_blocking_pids(pid),'query',left(query,400))),'[]')::text FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid() AND state<>'idle'`).Scan(&activity)
  item:=map[string]any{"at":time.Now().UTC().Format(time.RFC3339Nano)}
  if err!=nil {item["error"]=err.Error()}else{item["activity"]=json.RawMessage(activity)}
  if n%5==0 {
   var counts string
   err=db.QueryRow(`SELECT json_build_object('due',(SELECT count(*) FROM outbox_events WHERE status='PENDING' AND available_at<=now()),'published',(SELECT count(*) FROM outbox_events WHERE status='PUBLISHED'),'receipts',(SELECT count(*) FROM consumed_events),'projected',(SELECT coalesce(sum(order_count),0) FROM author_sales_daily))::text`).Scan(&counts)
   if err==nil{item["counts"]=json.RawMessage(counts)}
   groups,_:=client.XInfoGroups(ctx,stream).Result();item["groups"]=groups
   length,_:=client.XLen(ctx,stream).Result();item["stream_length"]=length
   first,_:=client.XRangeN(ctx,stream,"-","+",1).Result();if len(first)>0{item["first_stream_id"]=first[0].ID}
  }
  enc.Encode(item);time.Sleep(200*time.Millisecond)
 }
}
