import sys
from pathlib import Path
root=Path.cwd()
sys.path.insert(0,str(root/'scripts'))
import benchmark_backend as b
import inspect

# Reuse the verified preparation and measurement protocol, with isolated DB14.
start=inspect.getsource(b.start_api).replace("str(ROOT / 'bin/api')","str(ROOT / 'bin/api-diagnostic-warn')")
exec(start,b.__dict__)
source=(root/'scripts/benchmark_k6.py').read_text()
source=source.replace('import urllib.request','import urllib.request\nimport threading\nimport shutil')
source=source.replace("'15'","'14'").replace('redis_database=15','redis_database=14').replace("info['redis_database'] != 15","info['redis_database'] != 14")
source=source.replace('    finally:\n        import shutil','    finally:')
source=source.replace("REDIS_ADDR='127.0.0.1:6379')","REDIS_ADDR='127.0.0.1:6379', REDIS_DB='14', OUTBOX_STREAM='tokmall:diagnostic:events')")
source=source.replace('generator = None','generator = None\n        observer = None\n        profile_threads = []')
marker="            print('START', name, seconds, 'seconds', flush=True)"
instrument='''
            observer_env=dict(os.environ, OBSERVER_DSN=f'postgres://tokmall:tokmall@127.0.0.1:5432/{db}?sslmode=disable')
            observer=subprocess.Popen([str(b.ROOT/'bin/diagnostic-observer')], env=observer_env,
                stdout=(folder/'observer.jsonl').open('w'),stderr=(folder/'observer.log').open('w'))
            def profile(kind):
                time.sleep(5)
                suffix='?seconds=15' if kind in ['profile','block','mutex'] else '?debug=2'
                try:
                    with urllib.request.urlopen('http://127.0.0.1:19092/debug/pprof/'+kind+suffix,timeout=30) as result:
                        (folder/(kind+'.pprof' if kind!='goroutine' else 'goroutines.txt')).write_bytes(result.read())
                except Exception as error:
                    (folder/(kind+'-error.txt')).write_text(str(error))
            for kind in ['profile','block','mutex','goroutine']:
                thread=threading.Thread(target=profile,args=(kind,));thread.start();profile_threads.append(thread)
'''
assert marker in source;source=source.replace(marker,instrument+'\n'+marker)
marker="                summary['facts'] = facts"
snapshot='''
                subprocess.run([str(b.ROOT/'bin/diagnostic-observer')],env=dict(observer_env,SNAPSHOT='1'),
                    stdout=(folder/'stream.json').open('w'),check=True)
                missing=b.sql(db,"SELECT coalesce(json_agg(json_build_object('id',e.id,'event_id',e.event_id,'aggregate_id',e.aggregate_id,'attempts',e.attempts)),'[]') FROM outbox_events e WHERE status='PUBLISHED' AND NOT EXISTS (SELECT 1 FROM consumed_events c WHERE c.event_id=e.event_id)")
                (folder/'missing-events.json').write_text(missing)
'''
assert marker in source;source=source.replace(marker,snapshot+'\n'+marker)
source=source.replace('            b.stop(api)\n','''            if observer is not None:
                b.stop(observer)
            for thread in profile_threads:
                thread.join(timeout=5)
            b.stop(api)
            if (work/name/'logs').exists():
                shutil.copytree(work/name/'logs',folder/'service-logs',dirs_exist_ok=True)
''')
start=source.index('        feed = []')
end=source.index('    finally:',start)
source=source[:start]+'''        for name,scenario,vus,seconds,skus,maximum in [
            ('feed-c100-pool25-warn-profile','feed',100,30,1,10000),
        ]:
            env['OUTBOX_STREAM_MAX_LEN']=str(maximum)
            case(name,scenario,vus,seconds,skus)
'''+source[end:]
(root/'.gocache/diagnostics/2026-10-11/effective-runner.py').write_text(source)
sys.argv=['diagnostic','--output',str(root/'.gocache/diagnostics/2026-10-11/results'),'--resume']
exec(compile(source,'diagnostic-runner','exec'),{'__name__':'__main__'})
